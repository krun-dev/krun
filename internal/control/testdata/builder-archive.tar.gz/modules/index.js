// index.ts
var index_default = { async fetch(request, env) {
  const url = new URL(request.url);
  if (url.pathname === "/api/hello") return Response.json({ hello: true, release: env.KRUN_RELEASE_ID });
  return Response.json({ path: url.pathname });
} };

// __krun_entry__.mjs
import { WorkerEntrypoint } from "cloudflare:workers";
var krun_entry_default = index_default;
var KrunValidation = class extends WorkerEntrypoint {
  ping() {
    if (!index_default || typeof index_default.fetch !== "function") throw new Error("Default export must provide fetch");
    return { environment: this.env.KRUN_ENVIRONMENT, release_id: this.env.KRUN_RELEASE_ID };
  }
};
export {
  KrunValidation,
  krun_entry_default as default
};
